function login() {
  const user = document.getElementById('user').value;
  const pass = document.getElementById('pass').value;

  if (user === 'manotas' && pass === 'conejita123*') {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');

    cargarListaProductos();
  } else {
    alert('Datos incorrectos');
  }
}

function showAdmin(section) {
  document.getElementById('admin-productos').classList.add('hidden');
  document.getElementById('admin-sobremi').classList.add('hidden');
  document.getElementById('admin-familias').classList.add('hidden');

  if (section === 'productos') {
    document.getElementById('admin-productos').classList.remove('hidden');
  }

  if (section === 'sobremi') {
    document.getElementById('admin-sobremi').classList.remove('hidden');
  }

  if (section === 'familias') {
    document.getElementById('admin-familias').classList.remove('hidden');
    cargarFamilias();
  }
}

async function guardarProducto() {
  const nombre = document.getElementById('nombre').value;
  const precio = document.getElementById('precio').value;
  const descripcion = document.getElementById('descripcion').value;

  const imagenFile = document.getElementById('imagen').files[0];
  const pdfFile = document.getElementById('pdf').files[0];

  const imagenNombre = Date.now() + imagenFile.name;
  const pdfNombre = Date.now() + pdfFile.name;

  await supabaseClient.storage
    .from('productos')
    .upload(imagenNombre, imagenFile);

  await supabaseClient.storage
    .from('productos')
    .upload(pdfNombre, pdfFile);

  const imagenUrl = `${SUPABASE_URL}/storage/v1/object/public/productos/${imagenNombre}`;

  const pdfUrl = `${SUPABASE_URL}/storage/v1/object/public/productos/${pdfNombre}`;

  await supabaseClient
    .from('productos')
    .insert([
      {
        nombre,
        precio,
        descripcion,
        imagen: imagenUrl,
        pdf: pdfUrl
      }
    ]);

  alert('Producto guardado');

  cargarListaProductos();
}

async function cargarListaProductos() {
  const { data } = await supabaseClient
    .from('productos')
    .select('*');

  const lista = document.getElementById('lista-productos');

  lista.innerHTML = '';

  data.forEach(producto => {
    lista.innerHTML += `
      <div style="background:white;padding:15px;margin-top:15px;border-radius:12px;">
        <strong>${producto.nombre}</strong>
        <br>
        ${producto.precio}
        <br><br>
        <button onclick="eliminarProducto(${producto.id})">Eliminar</button>
      </div>
    `;
  });
}

async function eliminarProducto(id) {
  await supabaseClient
    .from('productos')
    .delete()
    .eq('id', id);

  cargarListaProductos();
}

async function guardarSobreMi() {
  const texto = document.getElementById('texto-sobremi').value;

  const archivos = document.getElementById('galeria-input').files;

  let urls = [];

  for (const file of archivos) {
    const nombre = Date.now() + file.name;

    await supabaseClient.storage
      .from('sobremi')
      .upload(nombre, file);

    urls.push(
      `${SUPABASE_URL}/storage/v1/object/public/sobremi/${nombre}`
    );
  }

  await supabaseClient
    .from('sobre_mi')
    .upsert([
      {
        id: 1,
        texto,
        galeria: urls.join(',')
      }
    ]);

  alert('Sobre mí actualizado');
}


async function guardarFamilia() {
  const nombre_tutor = document.getElementById('nombre-tutor').value;
  const paciente = document.getElementById('paciente').value;
  const usuario = document.getElementById('usuario-familia').value;
  const clave = document.getElementById('clave-familia').value;

  const { error } = await supabaseClient.from('familias').insert([{
    nombre_tutor, paciente, usuario, clave, activo: true
  }]);

  if (error) return alert(error.message);

  alert('Usuario creado');
  cargarFamilias();
}

async function cargarFamilias() {
  const { data } = await supabaseClient.from('familias').select('*').order('id',{ascending:false});
  const lista = document.getElementById('lista-familias');
  if(!lista) return;

  lista.innerHTML='';

  data.forEach(familia=>{
    lista.innerHTML += `
    <div class="familia-card">
      <strong>${familia.nombre_tutor}</strong><br>
      Paciente: ${familia.paciente}<br>
      Usuario: ${familia.usuario}<br>
      Estado: ${familia.activo ? '🟢 Activo' : '🔴 Inactivo'}<br><br>
      <button onclick="toggleFamilia(${familia.id}, ${familia.activo})">
      ${familia.activo ? 'Desactivar' : 'Activar'}
      </button>
    </div>`;
  });
}

async function toggleFamilia(id, activo) {
  await supabaseClient.from('familias').update({activo: !activo}).eq('id', id);
  cargarFamilias();
}
